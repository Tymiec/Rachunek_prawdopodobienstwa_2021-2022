W zadaniu 2_7 gdy zakomentujemy linijki od 4 do 21 możemy wygodnie wywołać program 
kilkukrotnie i prześledzić ile potrzeba prób
3_3 oraz 5_1 domyślnie zakomentowane jest zapisywanie wyników do plików